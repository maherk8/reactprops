import React, { Component } from 'react'

export default class Alert extends Component {
    render() {
        alert ("Hello world!");
        return (
            <div>
            
                 
            </div>
        )
    }
}
